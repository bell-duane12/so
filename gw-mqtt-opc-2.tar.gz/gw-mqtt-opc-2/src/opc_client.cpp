
#include "opc_client.hpp"
#include "cmakeconfig.hpp"
#include "common.h"
#include "com_types.hpp"
#include "mqtt_connection.hpp"

#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>
#include <open62541/client_subscriptions.h>
#include <open62541/plugin/log_stdout.h>

#include <thread>

using namespace std;
     

opc_client::opc_client(boost::asio::io_service &io_service,
                       logger& Logger,
                       std::string& map_file,
                       int polling_interval,
                       std::string& server_url,
                       std::string& user_token,
                       std::string& password_token,
                       int security_mode_1,
                       std::string& security_policy_1,
                       int security_mode_2,
                       std::string& security_policy_2,
                       std::string& cert_file,
                       std::string& private_key,
                       std::string& gw_uri,
                       bool use_source_timestamp,
                       bool use_encryption,
                       bool use_cert_file,
                       /*sqlite_client& sql_client,*/
                       unsigned int id_usina,
                       unsigned int timeout
                      ):
                      
  io_service_(io_service),
  logger_(Logger),
  poller_timer_(io_service_),
  map_file_(map_file),
  poller_timeout_(polling_interval),
  server_url_(server_url),
  user_token_(user_token),
  password_token_(password_token),
  security_mode_1_(security_mode_1),
  security_policy_1_(security_policy_1),
  security_mode_2_(security_mode_2),
  security_policy_2_(security_policy_2),
  cert_file_(cert_file),
  private_key_(private_key),
  gw_uri_(gw_uri),
  use_source_timestamp_(use_source_timestamp),
  use_encryption_(use_encryption),
  use_cert_file_(use_cert_file),
  /*sql_client_(sql_client),*/
  id_usina_(id_usina),
  timeout_(timeout) {
  
  // Constructor body

}

opc_client::~opc_client() {

  poller_timer_.cancel();

}

void opc_client::run() {

  logger_ << info << "GW OPC MQTT " << VERSION << " inicializado ..." << endlog;

  load_file();

  poller_timer_.expires_from_now(boost::posix_time::seconds(5));
  poller_timer_.async_wait(boost::bind(&opc_client::handle_opc_poller_timeout, this, boost::asio::placeholders::error));
        
  is_running_.store(true, std::memory_order_relaxed);

  io_service_.reset();
  io_service_.run();
        
}

void opc_client::stop() {

  logger_ << info << "GW OPC MQTT is stopping..." << endlog;
  io_service_.post(boost::bind(&opc_client::handle_stop, this));
  
}

void opc_client::handle_stop() {

  is_running_ = false;
  poller_timer_.cancel();
  
}

void opc_client::handle_opc_poller_timeout(const boost::system::error_code& error) {

  if (!error) {
    
    // Poll each listed opc variable
    poll_opc_server_variables();
   
  } else if (error != boost::asio::error::operation_aborted) { 
  
    logger_ << "opc_client::handle_opc_poller_timeout() - error: " << error << endlog;  
      
  }
  
  // Reset opc poller timer
  reset_poller_timer();
  
}

void opc_client::reset_poller_timer() {

  poller_timer_.expires_from_now(boost::posix_time::seconds(poller_timeout_));
  poller_timer_.async_wait(boost::bind(&opc_client::handle_opc_poller_timeout, this, boost::asio::placeholders::error));
  
}

void opc_client::reload_debug_log_level() {

  logger_.set_log_level("debHi");
  logger_ << info << "opc_client::reloadDebugLevel - messages logger set to 'debug'" << endlog;
  
}
    
void opc_client::reload_default_log_level() {

  logger_ << info << "opc_client::reloadDefaultLevel - messages logger set to: " << msgLogLevel << endlog;
  
  if (!logger_.set_log_level(msgLogLevel)) {
    logger_ << info << "opc_client::reloadDefaultLevel - messages logger set to 'never'" << endlog;
    logger_.set_log_level("never");
  }
  
}

/* Le do servidor o valor atual de todas as variaveis da usina que estiverem mapeadas. */
int opc_client::poll_opc_server_variables() {

  // Set up opc client
  logger_ << info << "Creating client pointer .. " << endlog;
  UA_Client* client = UA_Client_new();
  UA_ClientConfig* config = UA_Client_getConfig(client); 

  // Default timeout is 5 seconds
  config->timeout = timeout_;

  // Set Message Security Mode
  config->securityMode = UA_MESSAGESECURITYMODE_SIGNANDENCRYPT;
  
  // Set Security Policy
  config->securityPolicyUri = UA_String_fromChars(security_policy_1_.c_str()); 
  
  // Load certificate and private key, both in .der format
  logger_ << info << "Loading certificate and private key .. " << endlog;
  UA_ByteString certificate = loadFile(cert_file_.c_str());  
  UA_ByteString privateKey  = loadFile(private_key_.c_str());  

  // Load the trusted list
  size_t trustListSize = 0;
  //UA_ByteString* trustList = NULL;

  // Load the revocated list
  //UA_ByteString* revocationList = NULL;
  size_t revocationListSize = 0;
 
  // Set Client Connection Configurations
  UA_ClientConfig_setDefaultEncryption(config, certificate, privateKey,
                                       NULL, trustListSize,
                                       NULL, revocationListSize);

  // URI Matching the client self-signed certificate
  UA_String_clear(&config->clientDescription.applicationUri);  
  config->clientDescription.applicationUri = UA_STRING_ALLOC(gw_uri_.c_str());
                
  // Deallocation of byte strings        
  logger_ << info << "Deallocating certificate and private key .. " << endlog;   
  UA_ByteString_clear(&certificate);
  UA_ByteString_clear(&privateKey);

  // Connect to opc server
  logger_ << info << "Trying connection with opc server ... " << endlog;
  UA_StatusCode retval = UA_Client_connectUsername(client, server_url_.c_str(), user_token_.c_str(), password_token_.c_str()); 
  if(retval != UA_STATUSCODE_GOOD) {
  
    logger_ << info << "Client connection failed with StatusCode = " << UA_StatusCode_name(retval) << endlog;
    logger_ << info << "Could not connect!" << endlog;
    
    UA_Client_disconnect(client);
    UA_Client_delete(client);
    
    return EXIT_FAILURE;
    
  }

  // Poll all mapped variables ------------------------------------------------------
  logger_ << info << "\nPolling variables.." << endlog;
  UA_Variant val;
  size_t mapSize = nodeMap_.size();
  std::unordered_map<unsigned short, ets_data> equip_data;
  
  for(UA_UInt16 i = 0; i < mapSize; ++i) {

    UA_NodeId nodeId = UA_NODEID_STRING(std::get<0>(nodeMap_[i]), const_cast<char*>(std::get<1>(nodeMap_[i]).c_str()));

    retval = UA_Client_readValueAttribute(client, nodeId, &val);
    
    if(retval == UA_STATUSCODE_GOOD && UA_Variant_isScalar(&val)) {

      unsigned short ets = std::get<2>(nodeMap_[i]);
      unsigned short point = std::get<3>(nodeMap_[i]);
      
      if(val.type == &UA_TYPES[UA_TYPES_FLOAT]) {
       
        UA_Float value = *(UA_Float*) val.data;
        logger_ << debHi << std::get<1>(nodeMap_[i]) << " = " << value << endlog;
        equip_data[ets].analog.emplace_back(std::make_tuple(point, value, 0));
      
      }
      else if(val.type == &UA_TYPES[UA_TYPES_DOUBLE]) {
        
        UA_Double value = *(UA_Double*) val.data;
        logger_ << debHi << std::get<1>(nodeMap_[i]) << " = " << value << endlog;
        equip_data[ets].analog.emplace_back(std::make_tuple(point, value, 0));
        
      }
      else if(val.type == &UA_TYPES[UA_TYPES_INT16]) {
        
        UA_Int16 value = *(UA_Int16*) val.data;
        logger_ << debHi << std::get<1>(nodeMap_[i]) << " = " << value << endlog;
        equip_data[ets].counter.emplace_back(std::make_tuple(point, value, 0));
        
      }
      else if(val.type == &UA_TYPES[UA_TYPES_UINT16]) {
        
        UA_UInt16 value = *(UA_UInt16*) val.data;
        logger_ << debHi << std::get<1>(nodeMap_[i]) << " = " << value << endlog;
        equip_data[ets].counter.emplace_back(std::make_tuple(point, value, 0));
        
      }
      else if(val.type == &UA_TYPES[UA_TYPES_INT32]) {
        
        UA_Int32 value = *(UA_Int32*) val.data;
        logger_ << debHi << std::get<1>(nodeMap_[i]) << " = " << value << endlog;
        equip_data[ets].counter.emplace_back(std::make_tuple(point, value, 0));
        
      }
      else if(val.type == &UA_TYPES[UA_TYPES_UINT32]) {
        
        UA_UInt32 value = *(UA_UInt32*) val.data;
        logger_ << debHi << std::get<1>(nodeMap_[i]) << " = " << value << endlog;
        equip_data[ets].counter.emplace_back(std::make_tuple(point, value, 0));
        
      }
      else if(val.type == &UA_TYPES[UA_TYPES_INT64]) {
        
        UA_Int64 value = *(UA_Int64*) val.data;
        logger_ << debHi << std::get<1>(nodeMap_[i]) << " = " << value << endlog;
        equip_data[ets].counter.emplace_back(std::make_tuple(point, value, 0));
        
      }
      else if(val.type == &UA_TYPES[UA_TYPES_UINT64]) {
        
        UA_UInt64 value = *(UA_UInt64*) val.data;
        logger_ << debHi << std::get<1>(nodeMap_[i]) << " = " << value << endlog;
        equip_data[ets].counter.emplace_back(std::make_tuple(point, value, 0));
        
      }
      else if(val.type == &UA_TYPES[UA_TYPES_BOOLEAN]) {
        
        UA_Boolean value = *(UA_Boolean*) val.data;
        logger_ << debHi << std::get<1>(nodeMap_[i]) << " = " << value << endlog;
        equip_data[ets].binary.emplace_back(std::make_tuple(point, value, 0));
        
      }

    }

    UA_Variant_clear(&val);

  }
  
  UA_Variant_clear(&val);    
  
  // Send data to broker
  mqtt_connection::getInstance().mqtt_connection::serialize_and_send_to_broker(equip_data, ets_list_);
  
  // Close connection with opc server and delete client pointer
  logger_ << info << "Closing connection with opc server ... " << endlog;
  UA_Client_disconnect(client);
  UA_Client_delete(client);
    
  return EXIT_SUCCESS;
  
}

void opc_client::reload_data() {
    
  /*
  if (validator_.reload_data()) {
    //BOOST_LOG_TRIVIAL(info) << "opc_client::reload_data - Client data reloaded successfully!";
    logger_ << debug << "opc_client::reload_data - Client data reloaded successfully!" << endlog;
  }
  else {
    //BOOST_LOG_TRIVIAL(info) << "opc_client::reload_data - Client data reload failed!";
    logger_ << debug << "opc_client::reload_data - Client data reload failed!" << endlog;
  }*/
    
}

/* Carrega para a memoria as variaveis a serem monitoradas. */
void opc_client::load_file() {

  std::ifstream nodeMapFile(map_file_);
  std::string lineStr, s;
  size_t varPtrBegin, varPtrEnd, ns, ets, point, var_id(1);
  bool isDeviceCommFaultPoint;
  while (std::getline(nodeMapFile, lineStr)) {

    varPtrBegin = lineStr.find("=");
    varPtrEnd = lineStr.find(",");

    if (varPtrBegin != std::string::npos && varPtrEnd != std::string::npos) {

      ns = std::stoi(lineStr.substr(varPtrBegin+1, varPtrEnd-varPtrBegin-1));

      lineStr = lineStr.substr(varPtrEnd+1);
      varPtrBegin = lineStr.find("=");
      varPtrEnd = lineStr.find(",");

      if (varPtrBegin != std::string::npos && varPtrEnd != std::string::npos) {

        s = lineStr.substr(varPtrBegin+1, varPtrEnd-varPtrBegin-1);

        lineStr = lineStr.substr(varPtrEnd+1);
        varPtrBegin = lineStr.find("=");
        varPtrEnd = lineStr.find(",");

        if (varPtrBegin != std::string::npos && varPtrEnd != std::string::npos) {

          ets = std::stoi(lineStr.substr(varPtrBegin+1, varPtrEnd-varPtrBegin-1));

          lineStr = lineStr.substr(varPtrEnd+1);
          varPtrBegin = lineStr.find("=");
          varPtrEnd = lineStr.find(",");

          if (varPtrBegin != std::string::npos && varPtrEnd != std::string::npos) {

            point = std::stoi(lineStr.substr(varPtrBegin+1, varPtrEnd-varPtrBegin-1));

            lineStr = lineStr.substr(varPtrEnd+1);
            varPtrBegin = lineStr.find("=");
            varPtrEnd = lineStr.find(",");

            if (varPtrBegin != std::string::npos && varPtrEnd != std::string::npos) {

              isDeviceCommFaultPoint = std::stoi(lineStr.substr(varPtrBegin+1, varPtrEnd-varPtrBegin-1));

              nodeMap_.push_back(std::make_tuple(ns, s, ets, point, var_id, isDeviceCommFaultPoint, 0)); 
              ++var_id;

              // Se o ets nao existe na lista, o adiciona
              if (std::find(ets_list_.begin(), ets_list_.end(), ets) == ets_list_.end())
                ets_list_.push_back(ets);
              
            }

          }

        }

      }

    }

  }
  nodeMapFile.close();

  // Debuga as variaveis lidas do arquivo
  for (const auto& map_entry : nodeMap_) {

    logger_ << info << std::get<0>(map_entry) << ", " << std::get<1>(map_entry) <<
    ", " << std::get<2>(map_entry) << ", " << std::get<3>(map_entry) << ", " << std::get<4>(map_entry) << endlog;

  }

}


