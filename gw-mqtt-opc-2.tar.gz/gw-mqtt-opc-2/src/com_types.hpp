
#ifndef _COM_TYPES_HPP_
#define _COM_TYPES_HPP_


#include <vector>

#include <bits/stdint-uintn.h>
#include <bits/stdint-intn.h>


// Common definitions



typedef struct {
  std::vector<std::tuple<uint16_t, bool, int64_t>> binary;  
  std::vector<std::tuple<uint16_t, float, int64_t>> analog;  
  std::vector<std::tuple<uint16_t, uint32_t, int64_t>> counter;  

/*  
  std::vector<std::tuple<uint16_t, bool, int64_t>> binary_event;  
  std::vector<std::tuple<uint16_t, float, int64_t>> analog_event;  
  std::vector<std::tuple<uint16_t, uint32_t, int64_t>> counter_event; 
*/  
} ets_data;  // <point, value, timestamp> for each object type

/*
typedef struct {
  int serial;
  uint64_t seq_no;
  std::string type;
  std::string operation;
  uint32_t point;
  int int_val;
  float float_val;
  
} Command;*/


// DB Types -------------------------------
/*
typedef struct {
  unsigned int serial;
  int64_t timestamp;        // unix timestamp in milliseconds
  unsigned int id_usina;
  bool status_coleta_dados;
} TEtsStatusDB;

typedef struct {
  int64_t timestamp; 
  unsigned int id_usina;
  bool status_conexao_opc;
} TConnOpcStatusDB;

typedef struct {
  int64_t timestamp; 
  unsigned int id_usina;
  bool status_conexao_broker;
} TConnMqttStatusDB;
*/
// ----------------------------------------


#endif
