#ifndef _FILELOGHANDLER_H_
#define _FILELOGHANDLER_H_

#include "log_handler.hpp"

#include <boost/date_time/posix_time/posix_time.hpp>
#include <fstream>
#include <stdexcept>

using namespace boost::posix_time;

namespace util
{
  namespace log
  {

    class file_log_handler : public log_handler
    {
      public:

        file_log_handler(boost::asio::io_service &io_service, const std::string &file_name)
          : log_handler(io_service, file_name)
        {
          log_file_.open(file_name.c_str(), std::fstream::out | std::fstream::app);

          if (!log_file_.is_open())
          {
            throw (std::invalid_argument("Invalid log file: " + file_name));
          }

          facet_ = new boost::posix_time::time_facet("%d-%b-%Y %H:%M:%S");
          //cout.imbue(locale(cout.getloc(), facet));
          log_file_.imbue(std::locale(log_file_.getloc(), facet_));

        }

        void operator()(const std::string &str)
        {
          if (log_file_.is_open())
          {
            log_file_ << boost::posix_time::second_clock::local_time() << " - " << str << std::endl;
            //                  log_file_  << str << std::endl;
          }
        }

        ~file_log_handler()
        {
          if (log_file_.is_open())
          {
            log_file_.close();
          }
        }
      private:
        std::ofstream log_file_;
        boost::posix_time::time_facet *facet_;
    };

  }
}
#endif
