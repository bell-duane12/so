#ifndef _DEFAULTLOGHANDLER_H_
#define _DEFAULTLOGHANDLER_H_

#include "log_handler.hpp"
#include <iostream>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/thread.hpp>

namespace util
{
  namespace log
  {
    using namespace boost::posix_time;

    class default_log_handler : public log_handler
    {
      public:
        default_log_handler(boost::asio::io_service &io_service, const std::string &identifier) :
          log_handler(io_service, identifier) {}

        void operator()(const std::string &str)
        {
          //std::clog <<  boost::this_thread::get_id() << " - " << second_clock::local_time() << " [" << get_id() << "]" << " - " << str << std::endl;
          std::clog <<  second_clock::local_time() << " - " << str << std::endl;
        }
    };

  }
}
#endif
