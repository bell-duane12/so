//
// logger.hpp
// ~~~~~~~~~~
//
// Copyright (c) 2003-2008 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef _LOGGER_HPP
#define _LOGGER_HPP

#include "basic_logger.hpp"
#include "logger_service.hpp"
#include "rotating_file_log_handler.hpp"

#include "default_log_handler.hpp"

using namespace util::log;

/// Typedef for typical logger usage.

typedef basic_logger<rotating_file_log_handler, multi_threaded> logger_mt;

typedef basic_logger<rotating_file_log_handler> logger;

#endif // SERVICES_LOGGER_HPP
