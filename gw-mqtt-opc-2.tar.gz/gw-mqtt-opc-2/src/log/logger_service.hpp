//
// logger_service.hpp
// ~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2008 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef SERVICES_LOGGER_SERVICE_HPP
#define SERVICES_LOGGER_SERVICE_HPP

#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/noncopyable.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/shared_ptr.hpp>
#include <fstream>
#include <sstream>
#include <string>
#include <boost/unordered_map.hpp>


namespace util
{
  namespace log
  {
/// Service implementation for the logger.
    template <typename LogHandler>
    class logger_service : public boost::asio::io_service::service
    {
      public:

        typedef boost::shared_ptr<LogHandler> LogHandlerPtr;
        /// The unique service identifier.
        static boost::asio::io_service::id id;

        /// The type for an implementation of the logger.
        //typedef logger_impl* impl_type;

        /// Constructor creates a thread to run a private io_service.
        logger_service(boost::asio::io_service &io_service)
          : boost::asio::io_service::service(io_service),
            work_io_service_(),
            work_(new boost::asio::io_service::work(work_io_service_)),
            work_thread_(new boost::thread(
                            boost::bind(&boost::asio::io_service::run, &work_io_service_)))
            //log_handler_(work_io_service_)

        {

        }

        /// Destructor shuts down the private io_service.
        ~logger_service()
        {
          /// Indicate that we have finished with the private io_service. Its
          /// io_service::run() function will exit once all other work has completed.
          work_.reset();

          if (work_thread_)
          {
            work_thread_->join();
          }
        }

        /// Destroy all user-defined handler objects owned by the service.
        void shutdown_service()
        {
        }

        /// Create a new logger implementation.
        void create(LogHandlerPtr &handler, const std::string &identifier)
        {
          boost::mutex::scoped_lock map_lock(map_mutex_);
          typename log_handlers_type::iterator it = log_handlers_.find(identifier);

          if (it != log_handlers_.end())
          {
            handler = it->second;
          }
          else
          {
            handler.reset(new LogHandler(work_io_service_, identifier));
            log_handlers_.insert(std::make_pair(identifier, handler));
          }

          handler->increment_usage_count();
        }

        /// Destroy a logger implementation.
        void destroy(LogHandlerPtr &handler)
        {
          boost::mutex::scoped_lock map_lock(map_mutex_);
          handler->decrement_usage_count();

          if (handler->get_usage_count() == 0)
          {
            log_handlers_.erase(handler->get_id());
          }
        }

        /// Log a message.
        void log(LogHandlerPtr &handler, const std::string &message)
        {
          // Pass the work of opening the file to the background thread.
          work_io_service_.post(boost::bind(&logger_service::log_impl, this, handler, message));
        }

      private:
        /// Helper function used to log a message from within the private io_service's
        /// thread.
        void log_impl(LogHandlerPtr handler, const std::string &text)
        {
          (*handler)(text);
        }

        boost::asio::io_service work_io_service_;

        /// Work for the private io_service to perform. If we do not give the
        /// io_service some work to do then the io_service::run() function will exit
        /// immediately.
        boost::scoped_ptr<boost::asio::io_service::work> work_;

        /// Thread used for running the work io_service's run loop.
        boost::scoped_ptr<boost::thread> work_thread_;

//  LogHandler log_handler_;
        typedef boost::unordered_map<std::string, LogHandlerPtr> log_handlers_type;

        log_handlers_type log_handlers_;

        boost::mutex map_mutex_;
    };


    template <typename LogHandler>
    boost::asio::io_service::id logger_service<LogHandler>::id;

  }
}

#endif // SERVICES_LOGGER_SERVICE_HPP
