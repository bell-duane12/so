#ifndef _DEFAULTLOGGER_H_
#define _DEFAULTLOGGER_H_

#include "basic_logger.hpp"
#include "logger_service.hpp"
#include "default_log_handler.hpp"


using namespace util::log;

/// Typedef for typical logger usage.
typedef basic_logger<default_log_handler> logger;

#endif
