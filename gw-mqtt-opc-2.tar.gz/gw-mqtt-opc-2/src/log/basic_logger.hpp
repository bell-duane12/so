#ifndef BASIC_LOGGER_HPP
#define BASIC_LOGGER_HPP

#include <boost/asio.hpp>
#include <boost/noncopyable.hpp>
#include <boost/unordered_map.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/tss.hpp>
#include <string>
#include "logger_service.hpp"

namespace util
{
  namespace log
  {

    enum endlog_manipulator
    {
      endlog = 0
    };

    enum log_level
    {
      never = 0,
      error,
      info,
      debLo,
      debug,
      debHi
    };

/// Class to provide simple logging functionality. Use the services::logger
/// typedef.

    class single_threaded
    {
      public:
        inline std::ostringstream &get_ostream()
        {
          return (oss_);
        }
      private:
        std::ostringstream oss_;
    };

    class multi_threaded
    {
      public:

        std::ostringstream &get_ostream()
        {
          if (oss_thread_ptr_.get() == NULL)
          {
            oss_thread_ptr_.reset(new std::ostringstream);
          }

          return (*(oss_thread_ptr_.get()));
        }
      private:
        boost::thread_specific_ptr<std::ostringstream> oss_thread_ptr_;
    };

    template <typename LogHandler, typename ThreadPolicy = single_threaded>
    class basic_logger
    {
      public:
        typedef logger_service<LogHandler> service_type;

        typedef typename service_type::LogHandlerPtr LogHandlerPtr;

        /// Constructor.

        /**
          * This constructor creates a logger.
          *
          * @param io_service The io_service object used to locate the logger service.
          *
          * @param identifier An identifier for this logger.
          */
        explicit basic_logger(boost::asio::io_service &io_service,
                              const std::string &identifier) :
          service_(boost::asio::use_service<service_type>(io_service)),
          ignore_line_(false), log_level_(debug), handler_()
        {
          service_.create(handler_, identifier);
        }

        //NOTE: Comentado abaixo porque get_io_service não funciona!
        /*explicit basic_logger(basic_logger& logger) :
          service_(boost::asio::use_service<service_type>(logger.get_io_service())),
          log_level_(logger.log_level_),
          ignore_line_(false)
        {
            service_.create(handler_,logger.get_log_handler()->get_id());
          //handler_ = logger.get_log_handler();
          //handler_->increment_usage_count();
        }*/

        //NOTE: Comentado abaixo porque get_io_service não funciona!
        /*
        template <typename Thread>
        explicit basic_logger(basic_logger<LogHandler,Thread>& logger) :
          service_(boost::asio::use_service<service_type>(logger.get_io_service())),
          log_level_(logger.get_log_level()),
          ignore_line_(false)
        {
            service_.create(handler_,logger.get_log_handler()->get_id());
          //handler_ = logger.get_log_handler();
          //handler_->increment_usage_count();
        }*/

        /// Destructor.

        ~basic_logger()
        {
          service_.destroy(handler_);
        }

        bool set_log_level(log_level log_level)
        {
          log_level_ = log_level;
          return (true);
        }

        bool set_log_level(const std::string &log_level_str)
        {
          bool ok = true;

          if (log_level_str == "never")
          {
            log_level_ = never;
          }
          else if (log_level_str == "error")
          {
            log_level_ = error;
          }
          else if (log_level_str == "info")
          {
            log_level_ = info;
          }
          else if (log_level_str == "debLo")
          {
            log_level_ = debLo;
          }
          else if (log_level_str == "debug")
          {
            log_level_ = debug;
          }
          else if (log_level_str == "debHi")
          {
            log_level_ = debHi;
          }
          else
          {
            ok = false;
          }

          return (ok);
        }

        std::string log_level_str(const log_level level)
        {
          std::string str;

          if (level == never)
          {
            str = "never";
          }
          else if (level == error)
          {
            str = "error";
          }
          else if (level == info)
          {
            str = "info";
          }
          else if (level == debLo)
          {
            str = "debLo";
          }
          else if (level == debug)
          {
            str = "debug";
          }
          else if (level == debHi)
          {
            str = "debHi";
          }

          return (str);
        }

        log_level get_log_level()
        {
          return log_level_;
        }

        template <typename T>
        inline basic_logger &operator<<(const T &t)
        {
          if (!ignore_line_)
          {
            thread_policy_.get_ostream() << t;
          }

          return (*this);
        }

        inline basic_logger &operator<<(log_level log_level)
        {
          ignore_line_ = (log_level > log_level_ ? true : false);
          return (*this);
        }

        inline basic_logger &operator<<(const endlog_manipulator &m)
        {
          if (!ignore_line_)
          {
            std::ostringstream &oss =   thread_policy_.get_ostream();
            service_.log(handler_, oss.str());
            oss.str("");
            oss.clear();
          }

          return (*this);
        }

        void flush()
        {
          std::ostringstream &oss =   thread_policy_.get_ostream();
          service_.log(handler_, oss.str());
          oss.str("");
          oss.clear();
        }

        /// Get the io_service associated with the object.
        //TODO: Verificar porque esta dando erro aqui
        /*boost::asio::io_service& get_io_service()
        {
            return service_.get_io_service();
        }*/

        /// Log a message.
        void log(const std::string &message)
        {
          service_.log(handler_, message);
        }

        LogHandlerPtr &get_log_handler()
        {
          return (handler_);
        }
      private:
        /// The backend service implementation.
        service_type &service_;

        bool ignore_line_;
        log_level log_level_;
        /// The log handler pointer.
        LogHandlerPtr handler_;

        ThreadPolicy thread_policy_;
    };
  }
}


#endif // SERVICES_BASIC_LOGGER_HPP
