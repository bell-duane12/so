#ifndef _FILELOGHANDLER_H_
#define _FILELOGHANDLER_H_

#include "log_handler.hpp"

#include <boost/date_time/posix_time/posix_time.hpp>
#include <fstream>
#include <stdexcept>
#include <sstream>

using namespace boost::posix_time;

namespace util
{
  namespace log
  {

    class rotating_file_log_handler : public log_handler
    {
      public:

        rotating_file_log_handler(boost::asio::io_service &io_service, const std::string &identifier)
          : log_handler(io_service, identifier),
            file_rotation_timer_(io_service),
            identifier_(identifier)
        {
          rotate_file(true);
        }

        void operator()(const std::string &str)
        {
          if (log_file_.is_open())
          {
            log_file_ << second_clock::local_time() << " - " << str << std::endl;
          }
          else
          {
            throw (std::runtime_error("Trying to log with a closed log file"));
          }
        }


        ~rotating_file_log_handler()
        {
          if (log_file_.is_open())
          {
            log_file_.close();
          }
        }
      private:
        void handle_timeout(const boost::system::error_code &e)
        {
          if (!e)
          {
            rotate_file();
          }
          else
          {
            if (e != boost::asio::error::operation_aborted)
            {
              throw (std::runtime_error("Error while executing log file rotation - Timer error: " + e.message()));
            }
          }
        }
        void rotate_file(const bool first_time = false)
        {
          if (!first_time)
          {
            //boost::gregorian::date d  = boost::gregorian::day_clock::local_day(); // , hours(0));
            //d = d + boost::gregorian::days(1);
            //ptime next_update_time(d, hours(0));
            //log_file_ << second_clock::local_time() << " - " << "Next log rotate: " <<  next_update_time << std::endl;
//            log_file_.close();
          }

//          ptime now = second_clock::local_time();
//          boost::posix_time::time_facet *file_name_facet = new time_facet("%Y-%m-%d");
          std::ostringstream oss;
          oss.clear();
//          oss.imbue(std::locale(oss.getloc(), file_name_facet));
//          oss << identifier_ << "_" << now << ".log";

//          oss << identifier_ << ".log";
          oss << identifier_;

          log_file_.open(oss.str().c_str(), std::fstream::out | std::fstream::app);

          if (!log_file_.is_open())
          {
            throw (std::invalid_argument("Error creating log file: " + oss.str()));
          }

          facet_ = new time_facet("%d-%b-%Y %H:%M:%S");
          log_file_.imbue(std::locale(log_file_.getloc(), facet_));

//          reset_timer();
        }

        void reset_timer()
        {
          boost::gregorian::date d  = boost::gregorian::day_clock::local_day(); // , hours(0));
          d = d + boost::gregorian::days(1);
          ptime next_update_time(d, hours(0));
          //log_file_ << second_clock::local_time() << " - " << "Next log rotate: " <<  next_update_time << std::endl;
          //file_rotation_timer_.cancel();
          file_rotation_timer_.expires_at(next_update_time);
          file_rotation_timer_.async_wait(boost::bind(&rotating_file_log_handler::handle_timeout,
                                          this, boost::asio::placeholders::error));
        }

        std::ofstream log_file_;
        boost::asio::deadline_timer file_rotation_timer_;
        boost::posix_time::time_facet *facet_;
        const std::string identifier_;
    };

  }
}
#endif
