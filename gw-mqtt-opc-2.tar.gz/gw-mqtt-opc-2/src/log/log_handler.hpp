/*
 * File:   log_handler.hpp
 * Author: andre
 *
 * Created on September 18, 2008, 10:38 AM
 */

#ifndef _NULLLOG_HANDLER_HPP
#define _NULLLOG_HANDLER_HPP

#include <boost/asio.hpp>

namespace util
{
  namespace log
  {
    class log_handler
    {
      public:
        log_handler(boost::asio::io_service &io_service,
                    const std::string &identifier)
          : io_service_(io_service), identifier_(identifier), usage_count_(0U)
        {}
        inline const std::string &get_id()
        {
          return identifier_;
        }
        inline unsigned int get_usage_count()
        {
          return (usage_count_);
        }
        void increment_usage_count()
        {
          ++usage_count_;
        }
        void decrement_usage_count()
        {
          --usage_count_;
        }
        void operator()(const std::string &str)  {}
      protected:
        boost::asio::io_service &io_service_;
      private:
        const std::string identifier_;
        unsigned int usage_count_;
    };

  }
}
#endif  /* _LOG_HANDLER_HPP */
