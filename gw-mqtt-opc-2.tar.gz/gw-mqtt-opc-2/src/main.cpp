
#include <stdlib.h>
#include <iostream>
#include <fstream>

#include <boost/bind/bind.hpp>
#include <boost/asio.hpp>
#include <boost/log/trivial.hpp>
#include <boost/program_options.hpp>

#include "mqtt_connection.hpp"
#include "INIReader.h"
#include "main.hpp"
#include "log/logger.hpp"
#include "opc_client.hpp"
//#include "sqlite_client.hpp"


// Namespaces utilizados
using namespace std;

// Declara namespace 'po' para tratar "program options" (Boost)
namespace po = boost::program_options;

// Log level for boost trivial logger
boost::log::trivial::severity_level logLevel = boost::log::trivial::severity_level::info;

// Flag global que determina o estado da aplicacao
std::atomic<bool> running_(false);



int main(int argc, char *argv[]) {

  std::string cfg_filename = DEFAULT_CONFIG_FILE;
  
  // Definição das opções de linha de comando
  po::options_description desc("Program options");
  desc.add_options()
    ("cfg-filename,c", po::value<string>(&cfg_filename), "configuration filename for this gw-opc-mqtt")
    ("version,v", "shows program version")
    ("help,h", "shows usage help")
    ;
  po::variables_map vm;
  try {
    po::store(po::parse_command_line(argc, argv, desc), vm);
    po::notify(vm);
  }
  catch (std::exception& e) {
    BOOST_LOG_TRIVIAL(info) << e.what();
    return -1;
  }
  if ((vm.count("help")) || (!vm.size())) {
    show_version();
    BOOST_LOG_TRIVIAL(info) << desc;
    return 0;
  }  
  if (vm.count("version")) {
    show_version();
    return 0;
  }
  
  show_version();
  
  // Configura leitor do arquivo de configuração
  INIReader confReader(cfg_filename);
  
  // Carrega configuracoes opc
  auto node_file = confReader.Get("CONFIG", "node_file", "error");
  auto sampling_interval = confReader.GetInteger("CONFIG", "sampling_interval", 300);
  auto server_url = confReader.Get("CONFIG", "server_url", "error");
  auto user_token = confReader.Get("CONFIG", "user_token", "error");
  auto password_token = confReader.Get("CONFIG", "password_token", "error");
  auto security_mode_1 = confReader.GetInteger("CONFIG", "security_mode_1", 3);
  auto security_policy_1 = confReader.Get("CONFIG", "security_policy_1", "http://opcfoundation.org/UA/SecurityPolicy#Basic256Sha256");
  auto security_mode_2 = confReader.GetInteger("CONFIG", "security_mode_2", 1);
  auto security_policy_2 = confReader.Get("CONFIG", "security_policy_2", "http://opcfoundation.org/UA/SecurityPolicy#None");
  //auto conn_check = confReader.GetInteger("CONFIG", "conn_check", 2000);
  auto cert_file = confReader.Get("CONFIG", "cert", "error");
  auto private_key = confReader.Get("CONFIG", "private_key", "error");
  auto gw_uri = confReader.Get("CONFIG", "gw_uri", "error");
  auto use_opc_timestamp = confReader.GetBoolean("CONFIG", "use_opc_timestamp", false);
  auto use_encryption = confReader.GetBoolean("CONFIG", "use_encryption", false);
  auto use_cert_file = confReader.GetBoolean("CONFIG", "use_cert_file", false);
  auto opc_timeout = confReader.GetInteger("CONFIG", "opc_timeout", 13000);
  //auto fail_count = confReader.GetInteger("CONFIG", "fail_count", 3);

  // Obtem configuracoes do Log
  auto log_level = confReader.Get("CONFIG", "log_level", "debug");
  auto log_file = confReader.Get("CONFIG", "log_file", "error");

  // Obtem configuracoes do Broker MQTT
  auto gateway_id = confReader.GetInteger("CONFIG", "gateway_id", 99);
  auto broker_ip = confReader.Get("CONFIG", "broker_ip", "172.17.0.2");
  auto broker_port = confReader.GetInteger("CONFIG", "broker_port", 1883);
  auto broker_keepalive = confReader.GetInteger("CONFIG", "broker_keepalive", 60);
  auto broker_user = confReader.Get("CONFIG", "broker_user", "admin");
  auto broker_passw = confReader.Get("CONFIG", "broker_passw", "admin");

  // Obtem configuracao do banco de dados
  auto db_file_path = confReader.Get("CONFIG", "db_file_path", "error");
    
  // Central management object for asyncronous operations 
  boost::asio::io_service ios_;
  boost::asio::io_service::work work_(ios_);
      
  // Inicializa o objeto de log
  logger Logger(ios_, log_file);
  Logger.set_log_level(log_level);
  
  // Loga informacoes do programa na sua inicializacao
  Logger << info << ProgramId << " v" << ProgramVersion << endlog;
  Logger << info << Copyright1 << endlog;
  Logger << info << "Compiled " << __DATE__ << " " << __TIME__ << endlog;
  Logger << info << "Using configuration file name: " << cfg_filename << endlog;
  Logger << info << "Log level: " << log_level << endlog;
 
  // Instala sinais externos a aplicacao
  signal(SIGINT,  signalHandler);
  signal(SIGTERM, signalHandler);
  signal(SIGUSR1, signalHandler);
  signal(SIGUSR2, signalHandler);
  signal(SIGHUP,  signalHandler);

  // DB client object
  //sqlite_client sql_client_(ios_, db_file_path, Logger);
  
  // Setup OPC client
  opc_client opc_client_(ios_, Logger, node_file, sampling_interval, server_url, user_token,
                       password_token, security_mode_1, security_policy_1, security_mode_2, 
                       security_policy_2, cert_file, private_key, gw_uri, use_opc_timestamp,
                       use_encryption, use_cert_file, /*sql_client_,*/ gateway_id, opc_timeout);
  opc_client_.msgLogLevel = log_level;


  // Setup MQTT Client
  mqtt_connection::getInstance().setup_mqtt_client(broker_ip, broker_port, broker_keepalive, broker_user, broker_passw, gateway_id);
  //mqtt_connection::getInstance().set_fail_count(fail_count);
  
  // Inicializa Instancia MQTT
  try {

    mqtt_connection::getInstance().initialize(&ios_, &Logger, &opc_client_/*, &sql_client_*/);
    Logger << info << "MQTT instance initialized!" << endlog;

  } catch (...) {

    Logger << info << "Exception initializing MQTT instance!" << endlog;
    exit(EXIT_FAILURE);

  }

  // Signals and Slots
  terminateAppSignal.connect(boost::bind(&boost::asio::io_service::stop, &ios_));   
  reloadDebugLevelAppSignal.connect(boost::bind(&opc_client::reload_debug_log_level, &opc_client_));
  reloadDefaultLevelAppSignal.connect(boost::bind(&opc_client::reload_default_log_level, &opc_client_));
    
  running_ = true;
  opc_client_.run();
  //ios_.run();
  

  mqtt_connection::getInstance().shutdown();
  opc_client_.stop();
  //ios_.stop();

  BOOST_LOG_TRIVIAL(info) << "Disconnecting terminate signal from io_service...";
  terminateAppSignal.disconnect(boost::bind(&boost::asio::io_service::stop, &ios_));
  BOOST_LOG_TRIVIAL(info) << ProgramId << " Returning control to O.S.!!";
  
  exit(EXIT_SUCCESS);
  
}

void signalHandler(int signum) {

  BOOST_LOG_TRIVIAL(info) << "";
  BOOST_LOG_TRIVIAL(info) << "Got system signal #" << signum;
  
  switch (signum) {
  
    case SIGINT:
    case SIGTERM:
      BOOST_LOG_TRIVIAL(info) << "Shutting down application!";
      terminateAppSignal();
      running_.store(false, std::memory_order_relaxed);
      break;
    case SIGUSR1:
      BOOST_LOG_TRIVIAL(info) << "Alterando nivel de log para 'debHi'";
      reloadDebugLevelAppSignal();
      break;
    case SIGUSR2:
      BOOST_LOG_TRIVIAL(info) << "Alterando nivel de log para 'default'";
      reloadDefaultLevelAppSignal();
      break;
    case SIGHUP:
      BOOST_LOG_TRIVIAL(info) << "Reloading client data...";
      reloadClientDataAppSignal();
      break;
      
  }
  
}

void show_version() {

  BOOST_LOG_TRIVIAL(info) << "\n\n";
  BOOST_LOG_TRIVIAL(info) << ProgramId << " v" << ProgramVersion;
  BOOST_LOG_TRIVIAL(info) << Copyright1;
  BOOST_LOG_TRIVIAL(info) << "Compiled on " << __DATE__ << " " << __TIME__ << "\n\n";
  
}

