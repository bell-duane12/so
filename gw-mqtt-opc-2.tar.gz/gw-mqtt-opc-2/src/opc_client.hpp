#ifndef _OPC_CLIENT_HPP
#define _OPC_CLIENT_HPP


#include <boost/asio.hpp>
#include "log/logger.hpp"
//#include "sqlite_client.hpp"

class opc_client {

  public:

    opc_client(boost::asio::io_service& io_service,
               logger& Logger,
               std::string& map_file,
               int polling_interval,
               std::string& server_url,
               std::string& user_token,
               std::string& password_token,
               int security_mode_1,
               std::string& security_policy_1,
               int security_mode_2,
               std::string& security_policy_2,
               std::string& cert_file,
               std::string& private_key,
               std::string& gw_uri,
               bool use_source_timestamp,
               bool use_encryption,
               bool use_cert_file,
               /*sqlite_client& sql_client,*/
               unsigned int id_usina,
               unsigned int timeout
              );
              
    ~opc_client();
        
    // Starts the client
    void run();

    // Stops the client (it can be restarted)
    void stop();
    void handle_stop();

    void load_file();
    void reload_data();
    void reload_debug_log_level();
    void reload_default_log_level();
        
    // Mapa de nos a serem monitorados
    std::vector<std::tuple<int, std::string, int, int, int, bool, uint32_t>> nodeMap_;
    std::vector<unsigned short> ets_list_;
    std::string msgLogLevel;


  private:

    // The io_service used to perform asynchronous operations.
    boost::asio::io_service& io_service_;
    logger& logger_;
    //sqlite_client& sql_client_;
    boost::asio::deadline_timer poller_timer_;
    std::atomic<bool> is_running_;

    void handle_opc_poller_timeout(const boost::system::error_code& error);
    void reset_poller_timer();
    int poll_opc_server_variables();

    unsigned int id_usina_;
    unsigned int poller_timeout_;
    std::string& map_file_;
    std::string& server_url_;
    std::string& user_token_;
    std::string& password_token_;
    int security_mode_1_;
    std::string& security_policy_1_;
    int security_mode_2_;
    std::string& security_policy_2_;
    std::string& cert_file_;
    std::string& private_key_;
    std::string& gw_uri_;
    bool use_source_timestamp_;
    bool use_encryption_;
    bool use_cert_file_;
    unsigned int timeout_;

};



#endif  /* _OPC_CLIENT_HPP */
