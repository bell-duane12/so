
#ifndef _MQTT_CONNECTION_H
#define _MQTT_CONNECTION_H

#include <mosquitto.h>

#include "messages.pb.h"
#include "com_types.hpp"
#include "opc_client.hpp"
#include "log/logger.hpp"
//#include "sqlite_client.hpp"

#include <atomic>
#include <functional>
#include <queue>

#include <boost/noncopyable.hpp>
#include <boost/asio.hpp>
#include <boost/log/trivial.hpp>
#include <boost/lockfree/spsc_queue.hpp>
#include <boost/any.hpp>

#include <open62541/types.h>


class mqtt_connection : private boost::noncopyable {


private:
    
  static const char* host_;
  static int port_;
  static int keepalive_;
  static const char* user_;
  static const char* passw_;
    
  static std::atomic<int> gateway_id_;
  static std::atomic<unsigned int> ticket_;
  static std::atomic<bool> connected_;
  static std::atomic<bool> sss_status_;
    
  static struct mosquitto* mosq_;
  void* obj_mosq_;
    
private:
  
  mqtt_connection();
  ~mqtt_connection();

  // Callbacks
  static void on_connect(struct mosquitto* mosq, void* obj, int rc);
  static void on_disconnect(struct mosquitto* mosq, void* obj, int rc);
  static void on_publish(struct mosquitto* mosq, void* obj, int mid);
  static void on_subscribe(struct mosquitto* mosq, void* obj, int mid, int qos_count, const int* granted_qos);
  static void on_message(struct mosquitto* mosq, void* obj, const struct mosquitto_message* message);

  bool is_connected();
  static void set_connection_status(bool is_online);
  
  static void ok_keep_alive(int ticket);
  static void gw_status_notif();


  static logger* _logger;
  static boost::asio::io_service* io_service_;
  static boost::asio::io_service::strand* strand_;
  static opc_client* opc_client_ptr_;
  //static sqlite_client* sql_client_ptr_;

public:

  mqtt_connection(mqtt_connection const&) = delete;
  void operator=(mqtt_connection const&) = delete;
  static mqtt_connection& getInstance();
  void initialize(boost::asio::io_service* io_service,  logger* Logger, opc_client* opc_client_ptr);
  static void shutdown();

  static unsigned int get_ticket();
  static int get_gateway_id();
  static int64_t get_current_time();

  static void send_ets_status(uint16_t serial, bool is_online);
  static void ets_status_notif(uint32_t serial, bool is_online, int64_t current_time);

  static void set_sss_status(bool is_online);
  static bool get_sss_status();

  static void dispatch_upload(UploadToServer& upload);
  static void dispatch_notification(NotificationToServer& upload);

  static void set_gateway_id(const int gateway_id) {
    gateway_id_.store(gateway_id);
  }
    
  static void set_broker_ip(const char* host) {
    host_ = host;
  }
    
  static void set_broker_port(int port) {
    port_ = port;
  }
    
  static void set_broker_keepalive(int keepalive) {
    keepalive_ = keepalive;
  }
    
  static void set_broker_user(const char* user) {
    user_ = user;
  }
    
  static void set_broker_passw(const char* passw) {
    passw_ = passw;
  }
    
      
  static void setup_mqtt_client(std::string& broker_ip, int broker_port,
                                int broker_keepalive, std::string& broker_user,
                                std::string& broker_passw, int gateway_id);



  // Get ets and point from monitor id
  static bool getEtsAndPointFromMonitorID(const unsigned int monitor_id, int& ets, int& point, bool& is_ets_comm_fault_point);
  // Get ets and point from req id
  static bool getEtsAndPointFromRequisitionID(const unsigned int req_id, int& ets, int& point, bool& is_ets_comm_fault_point);

  static void serialize_and_send_to_broker(const std::unordered_map<unsigned short, ets_data>& equip_data, const std::vector<unsigned short>& ets_list);

  // Converte filetime/windows (nanosec 1/1/1601) UTC em timestamp unix (milisec 1/1/1970) local
  int64_t nano_ticks_to_unix_local_ms(UA_DateTime time);


  
};

#endif // _MQTT_CONNECTION_H
 
