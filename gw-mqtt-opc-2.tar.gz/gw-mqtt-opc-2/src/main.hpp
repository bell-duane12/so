
#pragma once

#include <string>
#include <boost/signals2.hpp> // Signals2 is thread safe
#include "cmakeconfig.hpp"


std::string DEFAULT_CONFIG_FILE("gw-opc-mqtt.conf");

std::string ProgramId("GW OPC MQTT");
std::string ProgramVersion(VERSION);
std::string Copyright1("(c) 2019-2023 ATI Ltda");


/** Sinal para informar à aplicação que ela deve ser terminada */
boost::signals2::signal<void ()> terminateAppSignal;
/** Sinal para informar à aplicação que ela deve recarregar arquivo de validação */
boost::signals2::signal<void ()> reloadClientDataAppSignal;
/** Sinal para informar à aplicação que ela deve recarregar o nivel de log */
boost::signals2::signal<void ()> reloadDebugLevelAppSignal;
/** Sinal para informar à aplicação que ela deve recarregar o nivel de log */
boost::signals2::signal<void ()> reloadDefaultLevelAppSignal;


void show_version();
void signalHandler(int signum);

