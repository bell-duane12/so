
#include "mqtt_connection.hpp"

#include <sstream>
#include <string>
#include <ctime>

#include "header.pb.h"
#include "command.pb.h"
#include "config.pb.h"
#include "objects.pb.h"

#include <boost/bind.hpp>



const char* mqtt_connection::host_ = 0;
int mqtt_connection::port_ = 0;
int mqtt_connection::keepalive_ = 0;
const char* mqtt_connection::user_ = 0;
const char* mqtt_connection::passw_ = 0;
std::atomic<int> mqtt_connection::gateway_id_(0);  
std::atomic<unsigned int> mqtt_connection::ticket_(0);  
std::atomic<bool> mqtt_connection::connected_(false);        
boost::asio::io_service* mqtt_connection::io_service_ = nullptr;
boost::asio::io_service::strand* mqtt_connection::strand_ = nullptr;
struct mosquitto* mqtt_connection::mosq_ = nullptr;
std::atomic<bool> mqtt_connection::sss_status_(false);
opc_client* mqtt_connection::opc_client_ptr_ = nullptr;
logger* mqtt_connection::_logger = nullptr;
//sqlite_client* mqtt_connection::sql_client_ptr_ = nullptr;



mqtt_connection::mqtt_connection() {
  set_connection_status(false);
}

void mqtt_connection::initialize(boost::asio::io_service* io_service,  logger* Logger, opc_client* opc_client_ptr/*, sqlite_client* sql_client_ptr*/) {
                                 //client_id_validator* client_id_validator_ptr,

  io_service_ = io_service;
  //strand_ = strand;
    
  opc_client_ptr_ = opc_client_ptr;
  _logger = Logger;
  //sql_client_ptr_ = sql_client_ptr;
  //client_id_validator_ptr_ = client_id_validator_ptr;
    
  mosquitto_lib_init();

  std::ostringstream mqttclient_id;
  mqttclient_id << "gw-opc-" << gateway_id_;
  mosq_ = mosquitto_new(mqttclient_id.str().c_str(), false, obj_mosq_);
    
  mosquitto_username_pw_set(mosq_, user_, passw_);

  mosquitto_connect_callback_set(mosq_, mqtt_connection::on_connect);
  mosquitto_disconnect_callback_set(mosq_, mqtt_connection::on_disconnect);
  mosquitto_subscribe_callback_set(mosq_, mqtt_connection::on_subscribe);
  mosquitto_message_callback_set(mosq_, mqtt_connection::on_message);
  mosquitto_publish_callback_set(mosq_, mqtt_connection::on_publish);

  mosquitto_connect_async(mosq_, host_, port_, keepalive_); 

  mosquitto_loop_start(mosq_);

  set_sss_status(false);

}

void mqtt_connection::set_connection_status(bool is_online) {
  connected_.store(is_online, std::memory_order_relaxed);
}

void mqtt_connection::set_sss_status(bool is_online) {
  sss_status_.store(is_online, std::memory_order_relaxed); 
}

bool mqtt_connection::get_sss_status() {
  return sss_status_.load(std::memory_order_relaxed);
}

mqtt_connection& mqtt_connection::getInstance() {
  
  static mqtt_connection instance;
  return instance;
    
}
  
mqtt_connection::~mqtt_connection() {
  shutdown();
}

void mqtt_connection::shutdown() {
  
  mosquitto_disconnect(mosq_);
  mosquitto_loop_stop(mosq_, true);
    
  if (mosq_ != nullptr)
    mosquitto_destroy(mosq_);
  mosquitto_lib_cleanup();

  mosq_ = nullptr;
  io_service_ = nullptr;

  google::protobuf::ShutdownProtobufLibrary();

}

bool mqtt_connection::is_connected() {
  return connected_.load(std::memory_order_relaxed);
}

unsigned int mqtt_connection::get_ticket() {
  return ticket_.fetch_add(1, std::memory_order_relaxed);
}

int mqtt_connection::get_gateway_id() {
  return gateway_id_.load(std::memory_order_relaxed);
}

void mqtt_connection::dispatch_upload(UploadToServer& upload) { 

  size_t size = upload.ByteSizeLong();
  char* msg = new char[size];
  upload.SerializeToArray(msg, size);

  (*_logger) << debHi << upload.DebugString() << endlog;

  std::ostringstream topic;
  topic << "gateway/" << gateway_id_ << "/rx";

  mosquitto_publish(mosq_, nullptr, topic.str().c_str(), size, msg, 1, false);

  delete[](char* ) msg;

}

void mqtt_connection::dispatch_notification(NotificationToServer& upload) {

  size_t size = upload.ByteSizeLong();
  char* msg = new char[size];
  upload.SerializeToArray(msg, size);

  (*_logger) << debHi << upload.DebugString() << endlog;

  std::ostringstream topic;
  topic << "gateway/" << gateway_id_ << "/notification";

  mosquitto_publish(mosq_, nullptr, topic.str().c_str(), size, msg, 1, false);

  delete[](char* ) msg;

}

void mqtt_connection::ok_keep_alive(int ticket) { 

  UploadToServer upload;
    
  upload.mutable_header()->set_protocol(PROT_ID_DNP3);
  upload.mutable_header()->set_msgtype(MSG_TYPE_GW);
  upload.mutable_header()->set_serial(get_gateway_id());
  upload.mutable_header()->set_ticket(ticket);
  upload.mutable_header()->set_gwid(get_gateway_id());
    
  upload.mutable_gwstatus()->set_configured(true);
  upload.mutable_gwstatus()->set_timestamp(get_current_time());
  upload.mutable_gwstatus()->set_sss_status(get_sss_status());
    
  (*_logger) << debHi << upload.DebugString() << endlog;

  dispatch_upload(upload);

}

void mqtt_connection::gw_status_notif() {

  NotificationToServer upload;
    
  upload.mutable_header()->set_protocol(PROT_ID_DNP3);
  upload.mutable_header()->set_msgtype(MSG_TYPE_GW);
  upload.mutable_header()->set_serial(get_gateway_id());
  upload.mutable_header()->set_ticket(get_ticket());
  upload.mutable_header()->set_gwid(get_gateway_id());
    
  upload.mutable_gwstatus()->set_configured(true);
  upload.mutable_gwstatus()->set_timestamp(get_current_time());
  upload.mutable_gwstatus()->set_sss_status(false);
    
  dispatch_notification(upload);

}

void mqtt_connection::ets_status_notif(uint32_t serial, bool is_online, int64_t current_time) {

  NotificationToServer upload;
    
  upload.mutable_header()->set_protocol(PROT_ID_DNP3);
  upload.mutable_header()->set_msgtype(MSG_TYPE_GW);
  upload.mutable_header()->set_serial(serial);
  upload.mutable_header()->set_ticket(get_ticket());
  upload.mutable_header()->set_gwid(get_gateway_id());
	
  upload.mutable_eqpstatus()->set_online(is_online);
  upload.mutable_eqpstatus()->set_timestamp(current_time);
    
  (*_logger) << debHi << upload.DebugString() << endlog;

  dispatch_notification(upload);
    
}

int64_t mqtt_connection::get_current_time() {

  // Number of milliseconds since 00:00:00 1/1/1970
  auto since_epoch = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
  return static_cast<int64_t>(since_epoch.count());

}

/*********************************
           CALLBACKS
*********************************/
void mqtt_connection::on_disconnect(struct mosquitto* mosq, void* obj, int rc) { 

  set_connection_status(false);
    
  switch(rc) {
      
    case 0:
      (*_logger) << debHi << ">> mqtt_connection - client has called mosquitto_disconnect " << endlog;
    break;

    default:
      (*_logger) << debHi << ">> mqtt_connection - unexpected disconnection, attempting to reconnect to broker with a delay of 1 second until the connection succeeds " << endlog;
    
  }

}

void mqtt_connection::on_connect(struct mosquitto* mosq, void* obj, int rc) { 

  switch(rc) {
      
    case 0:    // Success
    {

      set_connection_status(true);

      (*_logger) << debHi << ">> mqtt_connection - connected to broker" << endlog;

      std::ostringstream topic;
      topic << "gateway/" << gateway_id_ << "/tx";
      mosquitto_subscribe(mosq_, nullptr, topic.str().c_str(), 1);  // QoS = 1

    }
    break;

    case 1:    // Connection refused (unacceptable protocol version)
    {

      (*_logger) << debHi << ">> mqtt_connection - connection with broker refused (unacceptable protocol version)" << endlog;
      set_connection_status(false);

    }
    break;

    case 2:    // Connection refused (identifier rejected)
    {

      (*_logger) << debHi << ">> mqtt_connection - connection with broker refused (identifier rejected)" << endlog;
      set_connection_status(false);

    }
    break;

    case 3:    // Connection refused (broker unavailable)
    {

      (*_logger) << debHi << ">> mqtt_connection - connection with broker refused (broker unavailable)" << endlog;
      set_connection_status(false);
    }
    break;

  }

}

void mqtt_connection::on_publish(struct mosquitto* mosq, void* obj, int mid) { 
  
  (*_logger) << debHi << ">> mqtt_connection - Message (" << mid << ") successfully published to broker " << endlog;
    
}


void mqtt_connection::on_subscribe(struct mosquitto* mosq, void* obj, int mid, int qos_count, const int* granted_qos) { 
  
  (*_logger) << debHi << ">> mqtt_connection - Gateway subscribed to /tx topic " << endlog;

  gw_status_notif();

} 

void mqtt_connection::on_message(struct mosquitto* mosq, void* obj, const struct mosquitto_message* message) { 
/*  
  (*_logger) << debHi << ">> mqtt_connection - Gateway received message of topic: " << message->topic << endlog;

  std::string rxtopic(message->topic);
  std::ostringstream topic;
  topic << "gateway/" << gateway_id_ << "/tx";
    
  if (topic.str() == rxtopic) {

    UploadToGateway upload;

    if (upload.ParseFromArray(message->payload, message->payloadlen)) {

      (*_logger) << debHi << upload.DebugString();

      if (upload.has_header()) {

        if (upload.has_configgw()) {

          //upload.configgw()); 

        } else if (upload.has_checkgw()) {

          // Responde a requisicao de keep alive
          ok_keep_alive(upload.header().ticket());

        }
      }
    }
    return;
  }
*/
}

void mqtt_connection::setup_mqtt_client(std::string& broker_ip, int broker_port,
                              int broker_keepalive, std::string& broker_user,
                              std::string& broker_passw, int gateway_id) {

  mqtt_connection::set_broker_ip(broker_ip.c_str());
  mqtt_connection::set_broker_port(broker_port);
  mqtt_connection::set_broker_keepalive(broker_keepalive);
  mqtt_connection::set_broker_user(broker_user.c_str());
  mqtt_connection::set_broker_passw(broker_passw.c_str());

  mqtt_connection::set_gateway_id(gateway_id);

}

/*********************************
      HELPER FUNCTIONS
*********************************/
bool mqtt_connection::getEtsAndPointFromRequisitionID(const unsigned int req_id, int& ets, int& point, bool& is_ets_comm_fault_point) {
    
  // Busca ets e ponto correspondentes ao req_id
  auto it = std::find_if(opc_client_ptr_->nodeMap_.begin(), opc_client_ptr_->nodeMap_.end(),
                         [req_id] (const std::tuple<int, std::string, int, int, int, bool, uint32_t>& var) {
                           return (std::get<6>(var) == req_id);
                        });
    
  if (it != opc_client_ptr_->nodeMap_.end()) {
        
    ets = std::get<2>(*it);
    point =  std::get<3>(*it);
    is_ets_comm_fault_point = std::get<5>(*it);
    
    return true;
    
  }
    
  return false;

}

bool mqtt_connection::getEtsAndPointFromMonitorID(const unsigned int monitor_id, int& ets, int& point, bool& is_ets_comm_fault_point) {
        
  // Busca ets e ponto correspondentes ao monitor_id
  auto it = std::find_if(opc_client_ptr_->nodeMap_.begin(), opc_client_ptr_->nodeMap_.end(),
                         [monitor_id] (const std::tuple<int, std::string, int, int, int, bool, uint32_t>& var) {
                           return (std::get<4>(var) == monitor_id);
                        });
    
  if (it != opc_client_ptr_->nodeMap_.end()) {
        
    ets = std::get<2>(*it);
    point =  std::get<3>(*it);
    is_ets_comm_fault_point = std::get<5>(*it);
      
    return true;
      
  }
    
  return false;
  
}

/* Converte filetime/windows time em unix time.
 * A data de entrada representa a quantidade de intervalos de 100 nanosegundos desde 1 de Janeiro de 1601 (UTC). 
 * A data de saida representa o numero de milisegundos desde 1 de Janeiro de 1970 (local time).
 */
int64_t mqtt_connection::nano_ticks_to_unix_local_ms(UA_DateTime time) {
      
  time_t tim = (time_t) UA_DateTime_toUnixTime(time);
  return (int64_t) tim; 
    
}

void mqtt_connection::serialize_and_send_to_broker(const std::unordered_map<unsigned short, ets_data>& equip_data, const std::vector<unsigned short>& ets_list) {
    
  (*_logger) << debHi << "Serializing data and sending it to Broker .." << endlog;

  auto timestamp = get_current_time();

  // Varre a lista de equipamentos
  for (const auto& ets : ets_list) {

    // Procura pelo equipamento no buffer de dados dos ultimos 5 minutos
    auto it = equip_data.find(ets);
    
    // Se nao achou o equipamento no buffer de dados, envia notificacao de que ele esta down
    if (it == equip_data.end())
      ets_status_notif(ets, false, timestamp);
    
  }
  
  // Se nenhum dado foi coletado na ultima varredura, seta o status da usina como false, caso contrario: true
  if (equip_data.empty()) 
    set_sss_status(false);
  else
    set_sss_status(true);
  
  
  for (std::unordered_map<unsigned short, ets_data>::const_iterator it = equip_data.begin(); it != equip_data.end(); ++it) {
        
    auto current_device = it->first;
    
    NotificationToServer upload;
    
    upload.mutable_header()->set_protocol(PROT_ID_DNP3);
    upload.mutable_header()->set_msgtype(MSG_TYPE_GW);
    upload.mutable_header()->set_serial(current_device); 
    upload.mutable_header()->set_ticket(mqtt_connection::get_ticket());  
    upload.mutable_header()->set_gwid(mqtt_connection::get_gateway_id());   
    
    upload.mutable_eqpstatus()->set_online(true);  
    upload.mutable_eqpstatus()->set_timestamp(timestamp);
            
    // Fill ets data <point, value, timestamp>, <point, value, timestamp>, ..., for each group ---
    auto d = upload.mutable_notificationval()->add_staticlist();
    if ( ! it->second.binary.empty() ) {
        
      d->set_objtype(ObjType::OBJ_TYPE_BINARY_INPUT);
      for (auto& ets_binary : it->second.binary) {
                
        auto e = d->add_objvalues();
                    
        e->set_point(std::get<0>(ets_binary));         
        e->set_ivalue(std::get<1>(ets_binary));
        e->set_timestamp(timestamp);
        
      }
      
    }
    if ( ! it->second.analog.empty() ) {
        
      d = upload.mutable_notificationval()->add_staticlist();
      
      d->set_objtype(ObjType::OBJ_TYPE_ANALOG_INPUT);
      for (auto& ets_analog : it->second.analog) {

        auto e = d->add_objvalues();
                
        e->set_point(std::get<0>(ets_analog));         
        e->set_fvalue(std::get<1>(ets_analog));
        e->set_timestamp(timestamp);
        
      }
      
    }
    if ( ! it->second.counter.empty() ) {

      d = upload.mutable_notificationval()->add_staticlist();
      
      d->set_objtype(ObjType::OBJ_TYPE_BINARY_COUNTER);
      for (auto& ets_counter : it->second.counter) {

        auto e = d->add_objvalues();
                    
        e->set_point(std::get<0>(ets_counter));         
        e->set_ivalue(std::get<1>(ets_counter));
        e->set_timestamp(timestamp);
         
      }
      
    }
    
    // Send data to broker
    dispatch_notification(upload);
        
  }

  
}

